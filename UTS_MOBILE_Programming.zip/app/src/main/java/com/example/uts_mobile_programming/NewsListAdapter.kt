package com.example.uts_mobile_programming
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.TextView


class NewsListAdapter(context: Context, private val newsList: List<NewsItem>) :
    ArrayAdapter<NewsItem>(context, 0, newsList) {

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        var itemView = convertView
        if (itemView == null) {
            val inflater = LayoutInflater.from(context)
            itemView = inflater.inflate(R.layout.news_item, parent, false)
        }

        val currentNews = newsList[position]

        val titleTextView = itemView?.findViewById<TextView>(R.id.title_text_view)
        val contentTextView = itemView?.findViewById<TextView>(R.id.content_text_view)
        val dateTextView = itemView?.findViewById<TextView>(R.id.date_text_view)
        val timeTextView = itemView?.findViewById<TextView>(R.id.time_text_view)

        titleTextView?.text = currentNews.title
        contentTextView?.text = currentNews.content
        dateTextView?.text = currentNews.date
        timeTextView?.text = currentNews.time

        return itemView!!
    }
}

