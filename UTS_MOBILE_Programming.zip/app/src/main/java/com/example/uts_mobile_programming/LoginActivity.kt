package com.example.uts_mobile_programming

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        // Mengarahkan ke RegisterActivity saat tombol Register diklik
        val registerButton: Button = findViewById(R.id.register_button)
        val loginButton: Button = findViewById(R.id.login_button)
        registerButton.setOnClickListener {
            startActivity(Intent(this@LoginActivity, RegisterActivity::class.java))
        }

        // Mengarahkan ke DashboardActivity saat tombol Login diklik
        loginButton.setOnClickListener {
            startActivity(Intent(this@LoginActivity, NewsPortalActivity::class.java))
        }
    }
}