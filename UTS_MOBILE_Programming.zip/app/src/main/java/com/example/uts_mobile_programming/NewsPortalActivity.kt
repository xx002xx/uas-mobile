package com.example.uts_mobile_programming

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.ListView
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class NewsPortalActivity : AppCompatActivity() {
    private lateinit var newsListView: ListView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_news_portal)
        newsListView = findViewById(R.id.news_list_view)

        // Daftar berita tentang teknologi
        val technologyNewsList = arrayListOf(
            NewsItem(
                "Google Rilis Pixel 7 dengan Kamera 100 MP",
                "Google baru saja mengumumkan peluncuran smartphone terbarunya, Pixel 7. Salah satu fitur unggulan dari Pixel 7 adalah kamera utamanya yang memiliki resolusi 100 megapiksel. Ini membuatnya menjadi salah satu smartphone dengan kamera terbaik di pasaran.",
                getCurrentDate(),
                getCurrentTime()
            ),
            NewsItem(
                "Microsoft Merilis Windows 12 dengan Desain Baru",
                "Microsoft telah merilis versi terbaru dari sistem operasi Windows, yaitu Windows 12. Windows 12 hadir dengan desain yang lebih modern dan ramah pengguna, serta banyak fitur baru seperti integrasi yang lebih baik dengan layanan cloud dan peningkatan keamanan.",
                getCurrentDate(),
                getCurrentTime()
            ),
            NewsItem(
                "Apple Meluncurkan iPhone 15 dengan Layar Lipat",
                "Apple mengumumkan peluncuran iPhone 15 yang menghadirkan inovasi terbaru dalam desain smartphone. Salah satu fitur utamanya adalah layar lipat yang memungkinkan pengguna untuk mengubah iPhone menjadi tablet saat diperlukan.",
                getCurrentDate(),
                getCurrentTime()
            ),
            NewsItem(
                "Tesla Merilis Mobil Listrik Terbaru dengan Baterai yang Lebih Tahan Lama",
                "Tesla baru-baru ini mengumumkan peluncuran mobil listrik terbarunya, Model Y. Salah satu pembaruan utama dari Model Y adalah penggunaan baterai yang lebih tahan lama, memungkinkan pengguna untuk melakukan perjalanan jauh dengan lebih mudah.",
                getCurrentDate(),
                getCurrentTime()
            ),
            NewsItem(
                "Facebook Mengumumkan Rencana untuk Membangun Metaverse",
                "Facebook telah mengumumkan rencana ambisius untuk membangun metaverse, sebuah dunia virtual yang terhubung secara global. Ini akan menjadi platform baru yang menyatukan berbagai pengalaman digital seperti game, pertemuan virtual, dan lainnya.",
                getCurrentDate(),
                getCurrentTime()
            ),
            NewsItem(
                "Amazon Membuka Pusat Riset Kecerdasan Buatan Terbaru",
                "Amazon baru-baru ini membuka pusat riset kecerdasan buatan terbaru di Silicon Valley. Pusat riset ini akan fokus pada pengembangan teknologi AI yang dapat digunakan dalam berbagai produk dan layanan Amazon.",
                getCurrentDate(),
                getCurrentTime()
            ),
            NewsItem(
                "Sony Meluncurkan Konsol Game PlayStation 6 dengan Grafis 8K",
                "Sony telah meluncurkan konsol game terbarunya, PlayStation 6, yang dilengkapi dengan kemampuan grafis 8K. Ini membuatnya menjadi salah satu konsol game terkuat di pasaran, memungkinkan pengalaman gaming yang lebih imersif dan realistis.",
                getCurrentDate(),
                getCurrentTime()
            ),
            NewsItem(
                "TikTok Mengumumkan Fitur Baru untuk Membeli Produk Langsung dari Aplikasi",
                "TikTok telah mengumumkan fitur baru yang memungkinkan pengguna untuk membeli produk langsung dari aplikasi. Ini akan membantu mengubah platform tersebut menjadi lebih dari sekadar platform hiburan, tetapi juga sebagai platform perdagangan elektronik yang signifikan.",
                getCurrentDate(),
                getCurrentTime()
            ),
            NewsItem(
                "IBM Mengembangkan Superkomputer Tercepat di Dunia",
                "IBM telah mengumumkan pengembangan superkomputer tercepat di dunia, yang diberi nama Quantum Blue. Superkomputer ini memiliki kekuatan komputasi yang luar biasa, memungkinkan untuk menyelesaikan tugas-tugas yang sangat kompleks dalam waktu singkat.",
                getCurrentDate(),
                getCurrentTime()
            ),
            NewsItem(
                "Xiaomi Merilis Earbuds Baru dengan Fitur Pengurangan Kebisingan yang Lebih Baik",
                "Xiaomi baru-baru ini merilis earbuds terbaru mereka, yang dilengkapi dengan fitur pengurangan kebisingan yang lebih baik. Ini membuatnya menjadi salah satu earbuds terbaik untuk pengalaman mendengarkan musik yang lebih baik di lingkungan yang bising.",
                getCurrentDate(),
                getCurrentTime()
            )
        )

        // Buat adapter untuk ListView
        val adapter = NewsListAdapter(this, technologyNewsList)
        // Set adapter ke ListView
        newsListView.adapter = adapter
    }

    // Fungsi untuk mendapatkan tanggal saat ini dalam format "dd MMMM yyyy"
    private fun getCurrentDate(): String {
        val dateFormat = SimpleDateFormat("dd MMMM yyyy", Locale.getDefault())
        return dateFormat.format(Date())
    }

    // Fungsi untuk mendapatkan waktu saat ini dalam format "HH:mm"
    private fun getCurrentTime(): String {
        val timeFormat = SimpleDateFormat("HH:mm", Locale.getDefault())
        return timeFormat.format(Date())

    }
}