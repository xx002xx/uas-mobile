package com.example.uts_mobile_programming

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class RegisterActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_register)

        val usernameEditText: EditText = findViewById(R.id.username_editText)
        val passwordEditText: EditText = findViewById(R.id.password_editText)
        val registerButton: Button = findViewById(R.id.register_button)

        registerButton.setOnClickListener {
            val username = usernameEditText.text.toString()
            val password = passwordEditText.text.toString()

            // Log event
            Log.d("RegisterActivity", "Username: $username, Password: $password")

            // Tampilkan toast
            Toast.makeText(this@RegisterActivity, "Tombol Register diklik", Toast.LENGTH_SHORT).show()

            // Arahkan ke halaman login
            val intent = Intent(this@RegisterActivity, LoginActivity::class.java)
            startActivity(intent)
        }
    }
}