package com.example.uts_mobile_programming

data class NewsItem(val title: String, val content: String, val date: String, val time: String)
